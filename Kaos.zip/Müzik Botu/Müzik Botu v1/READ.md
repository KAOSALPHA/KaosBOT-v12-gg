Merhaba Arkadaşlar Ben Loz 'Bey

<br>Komutlar;

<br>!!bitir
<br>!!bul [SÖZ / URL]
<br>!!devam
<br>!!durdur
<br>!!döngü
<br>!!geç
<br>!!kuyruk
<br>!!ping
<br>!!şarkıadı
<br>!!sözler