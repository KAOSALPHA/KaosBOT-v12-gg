module.exports = client => {
  console.log(`Bağnlantın koptu! ${new Date()}`);
}; 